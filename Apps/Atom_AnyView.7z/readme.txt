Version: 1.0.0


Atom AnyView - Developer Chose to Be Anonymous

Point of app:
Video Viewer for movies / shows uploaded by user in a certain format (shown in Example folder)

How to use:
 - Click the upload files button
 - Upload a directory (e.g Avatar the Last Airbender - Water)
 - Click ok on the popup
 - Back and next buttons will allow video browsing
 - How to add your own videos:
  * Create a copy of Example folder
  * Change dir.json to the name and path of each video in your custom directory (please follow the valid json format)
  * In vid subfolder, upload all the videos with the path given in the json file.
  * Your custom directory should be viewable in Atom AnyView